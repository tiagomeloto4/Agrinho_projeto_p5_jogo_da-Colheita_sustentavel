// Jogo: Colheita Sustentável - versão com emojis

let player;
let items = [];
let score = 0;
let lives = 3;

let goodEmojis = ['🥕', '🍅', '🥦', '🥬'];
let badEmojis = ['🚬', '🗑️', '🍬', '🧪',];

function setup() {
  createCanvas(600, 400);
  textAlign(CENTER, CENTER);
  textSize(24);
  player = new Player();
  for (let i = 0; i < 6; i++) {
    items.push(new Item());
  }
}

function draw() {
  background(0, 191, 255); // fundo verde claro

  fill(0);
  textSize(18);
  text("❇️ Pontos: " + score, 80, 20);
  text("❤️ Vidas: " + lives, 500, 20);

  player.move();
  player.show();

  for (let i = 0; i < items.length; i++) {
    items[i].fall();
    items[i].show();

    if (items[i].hits(player)) {
      if (items[i].good) {
        score += 10;
      } else {
        lives -= 1;
      }
      items[i] = new Item(); // novo item
    }

    if (items[i].y > height) {
      items[i] = new Item();
    }
  }

  if (lives <= 0) {
    background(0);
    fill(255);
    textSize(32);
    text("💀 !Fim de jogo! 💀", width / 2, height / 2 - 20);
    textSize(24);
    text("Pontuação final: " + score, width / 2, height / 2 + 20);
    noLoop();
  }
}

class Player {
  constructor() {
    this.x = width / 2;
    this.y = height - 40;
    this.size = 40;
  }

  move() {
    if (keyIsDown(LEFT_ARROW)) this.x -= 6;
    if (keyIsDown(RIGHT_ARROW)) this.x += 6;
    this.x = constrain(this.x, 0, width - this.size);
  }

  show() {
    textSize(32);
    text("🧑‍🌾", this.x + this.size / 2, this.y);
  }
}

class Item {
  constructor() {
    this.x = random(20, width - 20);
    this.y = 0;
    this.speed = random(2, 4);
    this.good = random(1) > 0.5;
    this.emoji = this.good ? random(goodEmojis) : random(badEmojis);
  }

  fall() {
    this.y += this.speed;
  }
    textSize(28);
    text(this.emoji, this.x, this.y);
  }

  hits(player) {
    let distance = dist(this.x, this.y, player.x + player.size / 2, player.y);
    return distance < 30;
  }
}
